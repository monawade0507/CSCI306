// Authors: Demonna Wade & Erica Manzer

package levelPieces;

import gameEngine.Drawable;
import gameEngine.Moveable;

public class Kangaroo implements Moveable {

	char val;
	int loc; 

	// assigns values 
	public Kangaroo (char value )
	{
		val = value;
	}

	public void draw() {
		System.out.print(val);
	}
	
	// moves the place one location forward
	public void move(Drawable[] pieces, int playerLocation) {
		int i = playerLocation; 
		Doormat object = new Doormat(' '); 
		while (pieces[i] != null && i < 21 && i >= 0) {
			if (pieces[i] == object) {
				Drawable temp = pieces[playerLocation]; 
				pieces[playerLocation] = pieces[i]; 
				pieces[i] = temp; 
				pieces[playerLocation] = null; 
			}
			if (i == 20) {
				i = 0; 
			} 
			else {
			i++;
			}
		}
	}

}
